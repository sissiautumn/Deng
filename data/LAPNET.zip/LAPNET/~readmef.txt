lapnet 579tr. dist.=70.8, slowness410=-0.05, am410=0.0202, period410=5.7, tp410s=42.7,
slowness_pps=0.2, am_pps=0.0103, period_pps=6.4, tp0p410s=131.6, ratio=0.51 19 stations
STATIONS:
HEF
KEV
KIF
LP01
LP21
LP23
LP24
LP36
LP41
LP42
LP51
LP52
LP63
LP65
LP73
LP75
LP81
OUL
SGF
------------------------------
670 q-files  
nr
1
info_mean distance
!AVERAGE DISTANCE IS 6.707183e+01
slostack -0.5 0.5 0.05 67.0
shift all -50
t1t2
cut all -30 1
